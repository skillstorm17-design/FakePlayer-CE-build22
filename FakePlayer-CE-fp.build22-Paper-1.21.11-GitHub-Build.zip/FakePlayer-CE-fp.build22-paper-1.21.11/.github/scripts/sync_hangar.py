#!/usr/bin/env python3
"""与 Hangar (hangar.papermc.io) 同步。

两种模式:
  version --tag fp.build16   为指定 tag 创建 Hangar 版本 (外链指向 GitHub Release 资产)
  page                       把 README.md 同步为项目主页正文

鉴权是两步: POST /authenticate 用 API key 换 JWT, 之后所有请求用
`Authorization: HangarAuth <jwt>` (不是 Bearer)。
"""

import argparse
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = "https://hangar.papermc.io/api/v1"
PROJECT = os.environ.get("HANGAR_PROJECT", "FakePlayer-CE")
REPO = os.environ.get("GITHUB_REPOSITORY", "EndlessPixel-Studio/FakePlayer-CE")
TOKEN = os.environ.get("HANGAR_API_TOKEN", "")
COMMANDAPI_PROJECT_ID = 491
USER_AGENT = f"FakePlayer-CE-CI (+https://github.com/{REPO})"


def log(msg):
    print(msg, flush=True)


RETRY_STATUS = (429, 500, 502, 503, 504)


def http(url, method="GET", body=None, content_type=None, jwt=None, timeout=60, attempts=3):
    """带重试的请求。

    Hangar 前面挂着 Cloudflare, 发布时常出现 502/503 (build19 就是这样失败的)。
    上传接口对重复版本返回 409 + exist, 调用方已按"已存在"处理, 因此重试 POST 是安全的。
    """
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if content_type:
        headers["Content-Type"] = content_type
    if jwt:
        headers["Authorization"] = f"HangarAuth {jwt}"

    for attempt in range(attempts):
        req = urllib.request.Request(url, data=body, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.status, resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            status = e.code
            text = e.read().decode("utf-8", "replace")
        except (urllib.error.URLError, TimeoutError) as e:
            status = 0
            text = f"连接失败: {e}"

        if (status in RETRY_STATUS or status == 0) and attempt + 1 < attempts:
            delay = 5 * (attempt + 1)
            log(f"HTTP {status}, {delay} 秒后重试 {method} {url} ({attempt + 1}/{attempts})")
            time.sleep(delay)
            continue
        return status, text

    return status, text


def authenticate():
    if not TOKEN:
        sys.exit("缺少 HANGAR_API_TOKEN")
    url = f"{BASE}/authenticate?" + urllib.parse.urlencode({"apiKey": TOKEN})
    status, text = http(url, method="POST")
    if status == 200:
        return json.loads(text)["token"]
    sys.exit(f"鉴权失败 HTTP {status}: {text[:300]}")


def platform_versions_from_tag(tag):
    """从 tag 上各 NMSBridge 声明的 SUPPORTS 读出支持的 MC 版本。

    不能用目录名推断: 一个模块可以覆盖多个版本, 例如 v1_21_3 同时声明
    "1.21.2" 和 "1.21.3", v1_20_1 同时声明 "1.20" 和 "1.20.1"。

    旧 tag (build9 及以前) 的模块放在仓库根目录 (fakeplayer-v1_20_1/...),
    之后才收拢到 versions/ 下, 所以两条路径都要找。
    """
    out = subprocess.run(
        ["git", "grep", "-h", "SUPPORTS = Set.of", tag, "--", "versions/", "fakeplayer-v1_*"],
        capture_output=True, text=True,
    )
    if out.returncode != 0:
        sys.exit(f"读取 {tag} 的版本声明失败: {out.stderr.strip()}")
    versions = sorted({v for v in re.findall(r'"(\d[\d.]*)"', out.stdout)})
    if not versions:
        sys.exit(f"{tag} 里没有找到任何 SUPPORTS 声明")

    # 只保留 Hangar 平台表里认得的版本, 免得整个上传因为一个未来版本被拒
    status, text = http(f"{BASE}/platforms/PAPER/versions")
    if status == 200:
        known = set()
        for entry in json.loads(text):
            known.add(entry["version"])
            known.update(entry.get("subVersions") or [])
        unknown = [v for v in versions if v not in known]
        if unknown:
            log(f"跳过 Hangar 尚未收录的版本: {', '.join(sorted(unknown))}")
        versions = [v for v in versions if v in known]
    return sorted(versions, key=lambda v: [int(x) for x in v.split(".")])


def asset_url(tag):
    # tag 是 fp.build16, 资产名是 fakeplayer-fp.build16.jar (版本号本身不带 fp. 前缀)
    jar_version = tag[3:] if tag.startswith("fp.") else tag
    return f"https://github.com/{REPO}/releases/download/{tag}/fakeplayer-fp.{jar_version}.jar"


def wait_for_asset(tag, timeout=180):
    """Release 刚发布时资产可能还没挂上, 轮询到能拿到为止。"""
    url = asset_url(tag)
    deadline = time.time() + timeout
    while time.time() < deadline:
        status, _ = http(url, method="HEAD", timeout=30)
        if status == 200:
            return url
        log(f"资产还不可用 (HTTP {status}), 5 秒后重试: {url}")
        time.sleep(5)
    sys.exit(f"资产 3 分钟内仍不可用, 放弃: {url}")


def publish_version(tag):
    versions = platform_versions_from_tag(tag)
    log(f"{tag} 支持版本 ({len(versions)}): {', '.join(versions)}")

    url = wait_for_asset(tag)
    payload = {
        "version": tag,
        "channel": "Release",
        "description": f"https://github.com/{REPO}/releases/tag/{tag}",
        "platformDependencies": {"PAPER": versions},
        "pluginDependencies": {
            "PAPER": [
                {
                    "name": "CommandAPI",
                    "projectId": COMMANDAPI_PROJECT_ID,
                    "required": True,
                    "platform": "PAPER",
                }
            ]
        },
        "files": [{"platforms": ["PAPER"], "externalUrl": url}],
    }

    boundary = "----FakePlayerCEHangar"
    body = (
        f"--{boundary}\r\n"
        'Content-Disposition: form-data; name="versionUpload"\r\n'
        "Content-Type: application/json\r\n\r\n"
        + json.dumps(payload)
        + f"\r\n--{boundary}--\r\n"
    ).encode()
    status, text = http(
        f"{BASE}/projects/{PROJECT}/upload",
        method="POST",
        body=body,
        content_type=f"multipart/form-data; boundary={boundary}",
        jwt=authenticate(),
    )
    if status in (200, 201):
        log(f"已创建 {tag}: https://hangar.papermc.io/{PROJECT}/versions/{tag}")
        return
    if status in (400, 409) and ("exist" in text.lower() or "duplicate" in text.lower()):
        log(f"{tag} 已存在, 跳过")
        return
    sys.exit(f"创建 {tag} 失败 HTTP {status}: {text[:400]}")


def check_links():
    """校验 Hangar 上各版本记录的外链能不能真的下到文件。

    外链模式 (externalUrl) 下 Hangar 不落文件, 也不计下载数, 写错了永远不会
    报错, 只会给用户一条 404。所以判据是 HEAD 状态码, 而不是字符串比对:
    历史上 build3~build16 的文件名多写了一层 fp., 后来在 Release 上补了同内容
    的别名资产修正, 那条路仍然可用, 不该被判为异常。

    记录值与 asset_url(tag) 不一致时单独提示, 提醒命名可能偏离约定。
    """
    entries, offset = [], 0
    while True:  # Hangar 的 limit 上限是 25, 超过会被压回去, 只能翻页
        status, text = http(f"{BASE}/projects/{PROJECT}/versions?limit=25&offset={offset}")
        if status != 200:
            sys.exit(f"读取版本列表失败 HTTP {status}: {text[:300]}")
        page = json.loads(text)
        batch = page["result"]
        entries.extend(batch)
        offset += len(batch)
        if not batch or offset >= page["pagination"]["count"]:
            break

    ok, bad, skipped = [], [], []
    for entry in entries:
        tag = entry["name"]
        downloads = entry.get("downloads") or {}
        urls = [(p, (d or {}).get("externalUrl")) for p, d in downloads.items()]
        urls = [(p, u) for p, u in urls if u]
        if not urls:
            skipped.append(tag)
            continue
        problems, warnings = [], []
        for platform, url in urls:
            code, _ = http(url, method="HEAD", timeout=30)
            if code != 200:
                problems.append(f"{platform} HTTP {code} {url}")
            elif url != asset_url(tag):
                warnings.append(f"{platform} 可下载但命名偏离约定: {url}")
        (bad if problems else ok).append((tag, problems, warnings))

    log(f"可下载 {len(ok)} / 不可下载 {len(bad)} / 无外链 {len(skipped)}")
    warned = 0
    for tag, problems, warnings in ok + bad:
        if not problems and not warnings:
            continue
        log(f"\n[{tag}]")
        for line in problems:
            log(f"  错误: {line}")
        for line in warnings:
            log(f"  提示: {line}")
            warned += 1
    if warned:
        log(f"\n{len(set(t for t, p, w in ok + bad if w))} 个版本命名偏离约定但可下载")
    if bad:
        sys.exit(1)


def read_readme(path="README.md"):
    with open(path, encoding="utf-8") as f:
        return f.read()


def to_absolute(markdown):
    """相对链接改写成 GitHub 绝对地址, 并去掉只属于 GitHub 首页的装饰。"""
    blob = f"https://github.com/{REPO}/blob/master"

    markdown = markdown.replace('<div align="center">', "").replace("</div>", "")
    # 主页上的大 logo 在 Hangar 页面里显得突兀, 直接去掉
    markdown = re.sub(r'<img src="[^"]*" alt="[^"]*"[^>]*>\n*', "", markdown)
    markdown = re.sub(
        r"\]\((?!https?://|#|mailto:)([^)\s]+)\)",
        lambda m: f"]({path_url(m.group(1), blob)})",
        markdown,
    )
    return markdown.strip() + "\n"


def path_url(path, base):
    return f"{base}/{path[2:] if path.startswith('./') else path.lstrip('/')}"


def sync_page():
    content = to_absolute(read_readme())
    log(f"README 长度: {len(content)} 字符 (Hangar 上限 40000)")
    status, text = http(
        f"{BASE}/pages/editmain/{PROJECT}",
        method="PATCH",
        body=json.dumps({"path": "home", "content": content}).encode(),
        content_type="application/json",
        jwt=authenticate(),
    )
    if status not in (200, 204):
        sys.exit(f"同步主页失败 HTTP {status}: {text[:400]}")
    log(f"已同步主页: https://hangar.papermc.io/{PROJECT}/")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="mode", required=True)
    v = sub.add_parser("version")
    v.add_argument("--tag", required=True)
    sub.add_parser("page")
    sub.add_parser("check")
    args = parser.parse_args()

    if args.mode == "version":
        publish_version(args.tag)
    elif args.mode == "check":
        check_links()
    else:
        sync_page()
