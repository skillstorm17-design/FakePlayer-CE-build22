# Build for Paper 1.21.11 (Java 21)

This source package is configured to compile the existing FakePlayer-CE code for Paper 1.21.11 using Java 21 and only the matching `fakeplayer-v1_21_11` NMS provider.

## Build on Windows

1. Install a full JDK 21 (not just a JRE).
2. Extract this folder.
3. Run `BUILD_PAPER_1.21.11.bat`.
4. On success, the JAR is at `fakeplayer-dist\\build\\libs\\fakeplayer-fp.build22.jar`.

The first build needs internet access to download Gradle and project dependencies.

## Build with GitHub Actions

1. Create a GitHub repository or use a repository where you have permission to push.
2. Upload/push the complete contents of this folder, including the hidden `.github` directory.
3. Open the repository's **Actions** tab.
4. Select **Build Paper 1.21.11 plugin** and choose **Run workflow**.
5. When the run succeeds, download the artifact named `fakeplayer-fp.build22-paper-1.21.11`.
6. Extract the artifact to obtain `fakeplayer-fp.build22.jar`.

A failed workflow is not a plugin JAR. Share the complete failed build log to diagnose it.

## Important

- This is a source project until the build succeeds; do not upload the ZIP or source JAR to the server's `plugins` directory.
- Test the resulting JAR on a backup Paper 1.21.11 server before using it on a live SMP server.
- Keep the previous plugin JAR as a rollback backup.
