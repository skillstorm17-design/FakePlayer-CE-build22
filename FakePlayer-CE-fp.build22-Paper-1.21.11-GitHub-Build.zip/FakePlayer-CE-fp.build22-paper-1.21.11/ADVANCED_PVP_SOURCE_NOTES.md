# FakePlayer-CE build22 — Advanced PvP source and Paper 1.21.11 target

This directory contains the existing FakePlayer-CE project with advanced PvP source changes, configured to build a **Paper 1.21.11 / Java 21-only** distribution.

## Commands added

- `/fp follow <online-player> [fake-player]`
- `/fp fight <online-player> [fake-player]`
- `/fp guard [fake-player]`
- `/fp pvp <HT1|HT2|HT3|HT4|HT5|LT1|LT2|LT3|LT4|LT5> [fake-player]`
- `/fp pvpinfo [fake-player]`
- `/fp stop [fake-player]` cancels the AI mode as well as the existing movement action.

Existing FakePlayer-CE commands and AI chat source are retained.

## Combat behaviour represented in the source

- Individual AI mode state per fake-player UUID.
- Follow and fight stop if the target logs out, dies, or changes world.
- Guard searches nearby hostile `Monster` entities and returns to its saved post.
- Fight checks the world's PvP rule and can avoid same-scoreboard-team targets.
- Automatic armour scoring/equipping, melee weapon selection, bow/crossbow shots when arrows are available, shield/offhand-totem selection, food healing and a simple frontal damage-reduction approximation.
- HT1–HT5 and LT1–LT5 alter attack intervals and ranged spread only; the tier names are configurable skill labels, not calibrated esports rankings.

This is not a true vanilla client/player simulator. It does not fully simulate shield-use packets, axe shield disabling, mace smash timing, thrown tridents, potion rotations, pearl clutching or trained combat pathfinding/aim.

## Target conversion

The project contains an existing `fakeplayer-v1_21_11` NMS module. The build profile now selects only that module, updates the shared Paper compile API to `1.21.11-R0.1-SNAPSHOT`, changes the Java toolchain and bytecode target to 21, declares `api-version: '1.21'`, and packages only the 1.21.11 `NMSBridge` service provider.

See `PAPER_1.21.11_BUILD.md` for build and installation steps. This is source, not a compiled JAR.
