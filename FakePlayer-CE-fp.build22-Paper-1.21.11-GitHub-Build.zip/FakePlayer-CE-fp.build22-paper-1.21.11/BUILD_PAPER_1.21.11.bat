@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo FakePlayer-CE build22 - Paper 1.21.11 / Java 21
echo ================================================
where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java was not found. Install JDK 21 and add it to PATH.
  pause
  exit /b 1
)
java -version
for /f "tokens=3" %%v in ('java -version 2^>^&1 ^| findstr /i "version"') do set "JAVA_VERSION=%%~v"
for /f "tokens=1 delims=." %%v in ("%JAVA_VERSION%") do set "JAVA_MAJOR=%%v"
if not "%JAVA_MAJOR%"=="21" (
  echo ERROR: This target must be built with JDK 21. Detected: %JAVA_VERSION%
  echo Install JDK 21, set JAVA_HOME, and add its bin folder to PATH.
  pause
  exit /b 1
)
where javac >nul 2>nul
if errorlevel 1 (
  echo ERROR: javac was not found. Install a full JDK 21, not only a JRE.
  pause
  exit /b 1
)
call gradlew.bat :fakeplayer-dist:shadowJar --no-daemon --console=plain
if errorlevel 1 (
  echo BUILD FAILED. Copy the complete Gradle error log and share it for diagnosis.
  pause
  exit /b 1
)
echo.
echo BUILD SUCCESS.
echo JAR: fakeplayer-dist\build\libs\fakeplayer-fp.build22.jar
pause
