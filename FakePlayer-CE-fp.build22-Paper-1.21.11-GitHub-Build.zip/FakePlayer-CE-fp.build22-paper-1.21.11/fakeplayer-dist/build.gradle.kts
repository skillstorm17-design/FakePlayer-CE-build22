import java.util.zip.ZipFile

tasks.named<Jar>("jar") {
    enabled = false
}

dependencies {
    compileOnly(project(":fakeplayer-core"))
    compileOnly(project(":fakeplayer-api"))
    compileOnly(project(":fakeplayer-v1_21_11"))
}

tasks.register<Jar>("shadowJar") {
    archiveFileName.set("fakeplayer-${version}.jar")
    dependsOn(":fakeplayer-core:build")
    dependsOn(":fakeplayer-api:build")
    dependsOn(":fakeplayer-v1_21_11:build")

    val coreJar = project(":fakeplayer-core").tasks.named<Jar>("jar")
    from(coreJar.map { zipTree(it.archiveFile.get().asFile) })
    from(project(":fakeplayer-api").sourceSets.main.get().output)
    from(project(":fakeplayer-v1_21_11").sourceSets.main.get().output)
    from(sourceSets.main.get().output)

    // Include runtime dependencies from the core module.
    val runtimeClasspath = project(":fakeplayer-core").configurations.runtimeClasspath.get()
    from(runtimeClasspath.map { if (it.isDirectory) it else zipTree(it) })

    duplicatesStrategy = DuplicatesStrategy.EXCLUDE

    doLast {
        ZipFile(archiveFile.get().asFile).use { jar ->
            check(jar.getEntry("plugin.yml") != null) { "Distribution JAR is missing plugin.yml" }
            val servicePath = "META-INF/services/io.github.hello09x.fakeplayer.api.spi.NMSBridge"
            val services = jar.getEntry(servicePath)
                ?: error("Distribution JAR is missing the NMS bridge service descriptor")
            val providers = jar.getInputStream(services).bufferedReader().useLines { lines ->
                lines.map(String::trim).filter { it.isNotEmpty() && !it.startsWith("#") }.toList()
            }
            val expected = "io.github.hello09x.fakeplayer.v1_21_11.spi.NMSBridgeImpl"
            check(providers == listOf(expected)) { "Expected only the Paper 1.21.11 NMS provider, found: $providers" }
            check(jar.getEntry(expected.replace('.', '/') + ".class") != null) {
                "Distribution JAR is missing the Paper 1.21.11 NMS bridge provider"
            }
        }
    }
}

tasks.named("assemble") {
    dependsOn("shadowJar")
}
