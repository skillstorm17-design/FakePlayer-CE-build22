package io.github.hello09x.fakeplayer.core.manager.combat;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.github.hello09x.fakeplayer.api.spi.ActionSetting;
import io.github.hello09x.fakeplayer.api.spi.ActionType;
import io.github.hello09x.fakeplayer.core.Main;
import io.github.hello09x.fakeplayer.core.manager.action.ActionManager;
import io.github.hello09x.fakeplayer.core.util.WalkUtils;
import java.io.File;
import java.util.Comparator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.util.Vector;
import org.bukkit.configuration.file.YamlConfiguration;
import org.jetbrains.annotations.NotNull;

/**
 * Optional player-like combat controller for FakePlayer-CE fake players.
 * All entity/world operations are made from FakeplayerTicker's entity scheduler (Folia-safe).
 */
@Singleton
public final class CombatAIManager implements Listener {

  public enum Mode { FOLLOW, FIGHT, GUARD }

  public enum PvpTier {
    HT1(6, "Elite"), HT2(8, "Very advanced"), HT3(10, "Advanced"),
    HT4(12, "Strong"), HT5(14, "High-level"),
    LT1(16, "Pro"), LT2(19, "Intermediate"), LT3(22, "Average"),
    LT4(26, "Beginner"), LT5(30, "Very beginner");

    private final int attackInterval;
    private final String description;

    PvpTier(int attackInterval, String description) {
      this.attackInterval = attackInterval;
      this.description = description;
    }

    public int attackInterval() { return attackInterval; }
    public String description() { return description; }

    public static PvpTier parse(String value) {
      return PvpTier.valueOf(value.toUpperCase(java.util.Locale.ROOT));
    }
  }

  private static final class State {
    private final Mode mode;
    private final UUID target;
    private final String targetName;
    private final Location guardLocation;
    private long nextAttackTick;
    private long nextMoveTick;
    private long nextGearTick;
    private long nextDodgeTick;
    private Location lastMoveTarget;

    private State(Mode mode, UUID target, String targetName, Location guardLocation) {
      this.mode = mode;
      this.target = target;
      this.targetName = targetName;
      this.guardLocation = guardLocation == null ? null : guardLocation.clone();
    }
  }

  private final ActionManager actionManager;
  private final Map<UUID, State> states = new ConcurrentHashMap<>();
  private final Map<UUID, PvpTier> tiers = new ConcurrentHashMap<>();
  private final YamlConfiguration settings;

  @Inject
  public CombatAIManager(ActionManager actionManager) {
    this.actionManager = actionManager;
    File file = new File(Main.getInstance().getDataFolder(), "combat-ai.yml");
    if (!file.exists()) {
      Main.getInstance().saveResource("combat-ai.yml", false);
    }
    this.settings = YamlConfiguration.loadConfiguration(file);
  }

  public void follow(@NotNull Player fake, @NotNull Player target) {
    states.put(fake.getUniqueId(), new State(Mode.FOLLOW, target.getUniqueId(), target.getName(), null));
    cancelGoto(fake);
  }

  public void fight(@NotNull Player fake, @NotNull Player target) {
    states.put(fake.getUniqueId(), new State(Mode.FIGHT, target.getUniqueId(), target.getName(), null));
    cancelGoto(fake);
  }

  public void guard(@NotNull Player fake) {
    states.put(fake.getUniqueId(), new State(Mode.GUARD, null, null, fake.getLocation()));
    cancelGoto(fake);
  }

  public void stop(@NotNull Player fake) {
    states.remove(fake.getUniqueId());
    cancelGoto(fake);
  }

  public void setTier(@NotNull Player fake, @NotNull PvpTier tier) {
    tiers.put(fake.getUniqueId(), tier);
  }

  public @NotNull PvpTier getTier(@NotNull Player fake) {
    return tiers.getOrDefault(fake.getUniqueId(), PvpTier.LT3);
  }

  public boolean requiresWorldPvp() {
    return settings.getBoolean("pvp.require-world-pvp", true);
  }

  public String getMode(@NotNull Player fake) {
    State state = states.get(fake.getUniqueId());
    return state == null ? "IDLE" : state.mode.name();
  }

  /** Called once per fake-player tick by FakeplayerTicker on that entity's owning region. */
  public void tick(@NotNull Player fake) {
    State state = states.get(fake.getUniqueId());
    if (state == null) return;
    if (!fake.isOnline() || fake.isDead() || !fake.isValid()) {
      states.remove(fake.getUniqueId());
      return;
    }

    long tick = fake.getTicksLived();
    if (tick >= state.nextGearTick) {
      state.nextGearTick = tick + 20;
      if (settings.getBoolean("equipment.auto-equip-armour", true)) equipBestArmor(fake);
      if (settings.getBoolean("equipment.auto-equip-shield", true)) equipDefensiveOffhand(fake);
      if (settings.getBoolean("equipment.auto-select-weapon", true)) selectBestMeleeWeapon(fake);
      if (settings.getBoolean("equipment.auto-heal", true)) tryEatFood(fake);
    }
    if (tick % 5 != 0) return;

    if (state.mode == Mode.GUARD) {
      tickGuard(fake, state, tick);
      return;
    }

    Player target = state.target == null ? null : Bukkit.getPlayer(state.target);
    if (target == null || !target.isOnline() || target.isDead()) {
      stop(fake);
      return;
    }
    if (target.getWorld() != fake.getWorld()) {
      stop(fake);
      return;
    }

    if (state.mode == Mode.FOLLOW) {
      double followDistance = settings.getDouble("follow.distance", 3.5);
      if (fake.getLocation().distanceSquared(target.getLocation()) > followDistance * followDistance) {
        moveTowards(fake, target.getLocation(), state, tick);
      } else {
        cancelGoto(fake);
        state.lastMoveTarget = null;
      }
      return;
    }

    if (state.mode == Mode.FIGHT) {
      if (settings.getBoolean("pvp.require-world-pvp", true) && !fake.getWorld().getPVP()) {
        stop(fake);
        return;
      }
      if (settings.getBoolean("pvp.respect-scoreboard-teams", true) && sameTeam(fake, target)) {
        stop(fake);
        return;
      }
      tickFight(fake, target, state, tick);
    }
  }

  private void tickGuard(Player fake, State state, long tick) {
    double range = settings.getDouble("guard.range", 14.0);
    Entity nearest = fake.getNearbyEntities(range, range, range).stream()
        .filter(entity -> entity instanceof Monster && entity.isValid() && !entity.isDead())
        .min(Comparator.comparingDouble(entity -> entity.getLocation().distanceSquared(fake.getLocation())))
        .orElse(null);

    if (nearest instanceof LivingEntity hostile) {
      tickFight(fake, hostile, state, tick);
      return;
    }

    double returnDistance = settings.getDouble("guard.return-distance", 2.5);
    if (state.guardLocation != null
        && (fake.getWorld() != state.guardLocation.getWorld()
            || fake.getLocation().distanceSquared(state.guardLocation) > returnDistance * returnDistance)) {
      moveTowards(fake, state.guardLocation, state, tick);
    } else {
      cancelGoto(fake);
      state.lastMoveTarget = null;
    }
  }

  private void tickFight(Player fake, LivingEntity target, State state, long tick) {
    if (!target.isValid() || target.isDead() || target.getWorld() != fake.getWorld()) return;
    double distanceSquared = fake.getLocation().distanceSquared(target.getLocation());
    double rangedDistance = settings.getDouble("combat.ranged-distance", 9.0);
    boolean hasRanged = hasArrow(fake.getInventory()) && findRangedWeapon(fake.getInventory()) >= 0;

    if (distanceSquared > rangedDistance * rangedDistance || (distanceSquared > 25 && hasRanged)) {
      if (hasRanged && tick >= state.nextAttackTick) {
        fireArrow(fake, target);
        state.nextAttackTick = tick + getTier(fake).attackInterval() * 2L;
      } else {
        moveTowards(fake, target.getLocation(), state, tick);
      }
      return;
    }

    double meleeRange = settings.getDouble("combat.melee-range", 4.2);
    if (distanceSquared > meleeRange * meleeRange) {
      moveTowards(fake, target.getLocation(), state, tick);
      return;
    }

    cancelGoto(fake);
    state.lastMoveTarget = null;
    if (tick < state.nextAttackTick) return;
    selectBestMeleeWeapon(fake);
    fake.swingMainHand();
    target.damage(weaponDamage(fake.getInventory().getItemInMainHand()), fake);
    state.nextAttackTick = tick + getTier(fake).attackInterval();
  }

  private void moveTowards(Player fake, Location destination, State state, long tick) {
    if (tick < state.nextMoveTick) return;
    state.nextMoveTick = tick + 8;
    if (destination.getWorld() != fake.getWorld()) return;
    if (state.lastMoveTarget != null
        && state.lastMoveTarget.getWorld() == destination.getWorld()
        && state.lastMoveTarget.distanceSquared(destination) < 4.0
        && actionManager.hasActiveAction(fake, ActionType.GOTO)) return;
    Location stand = WalkUtils.findStandLocation(fake, destination.getBlock());
    if (stand == null) return;
    ActionSetting setting = ActionSetting.continuous();
    setting.targetX = stand.getX();
    setting.targetY = stand.getY();
    setting.targetZ = stand.getZ();
    actionManager.setAction(fake, ActionType.GOTO, setting);
    state.lastMoveTarget = destination.clone();
  }

  private void cancelGoto(Player fake) {
    if (actionManager.hasActiveAction(fake, ActionType.GOTO)) {
      actionManager.setAction(fake, ActionType.GOTO, ActionSetting.stop());
    }
  }

  private void equipBestArmor(Player fake) {
    PlayerInventory inventory = fake.getInventory();
    ItemStack[] armor = inventory.getArmorContents();
    String[] suffixes = {"_BOOTS", "_LEGGINGS", "_CHESTPLATE", "_HELMET"};
    for (int armorSlot = 0; armorSlot < armor.length; armorSlot++) {
      ItemStack current = armor[armorSlot];
      int currentScore = armorScore(current, suffixes[armorSlot]);
      ItemStack[] storage = inventory.getStorageContents();
      int bestSlot = -1;
      int bestScore = currentScore;
      for (int slot = 0; slot < storage.length; slot++) {
        ItemStack candidate = storage[slot];
        int score = armorScore(candidate, suffixes[armorSlot]);
        if (score > bestScore) {
          bestScore = score;
          bestSlot = slot;
        }
      }
      if (bestSlot >= 0) {
        ItemStack candidate = inventory.getItem(bestSlot);
        inventory.setItem(bestSlot, current == null || current.getType().isAir() ? null : current.clone());
        armor[armorSlot] = candidate.clone();
      }
    }
    inventory.setArmorContents(armor);
  }

  private int armorScore(ItemStack item, String requiredSuffix) {
    if (item == null || item.getType().isAir() || !item.getType().name().endsWith(requiredSuffix)) return -1;
    String name = item.getType().name();
    int materialTier = name.startsWith("NETHERITE") ? 6
        : name.startsWith("DIAMOND") ? 5
        : name.startsWith("IRON") ? 4
        : name.startsWith("CHAINMAIL") ? 3
        : name.startsWith("GOLDEN") ? 2
        : name.startsWith("LEATHER") ? 1 : 0;
    int durability = item.getType().getMaxDurability();
    int wearScore = 0;
    if (durability > 0 && item.getItemMeta() instanceof org.bukkit.inventory.meta.Damageable damageable) {
      wearScore = Math.max(0, 100 - (damageable.getDamage() * 100 / durability));
    }
    return materialTier * 1000 + wearScore;
  }

  private void equipDefensiveOffhand(Player fake) {
    PlayerInventory inventory = fake.getInventory();
    Material preferred = fake.getHealth() <= settings.getDouble("equipment.equip-totem-below-health", 6.0)
        ? Material.TOTEM_OF_UNDYING : Material.SHIELD;
    if (inventory.getItemInOffHand().getType() == preferred) return;
    ItemStack[] storage = inventory.getStorageContents();
    for (int slot = 0; slot < storage.length; slot++) {
      if (storage[slot] != null && storage[slot].getType() == preferred) {
        ItemStack oldOffhand = inventory.getItemInOffHand();
        inventory.setItem(slot, oldOffhand == null || oldOffhand.getType().isAir() ? null : oldOffhand.clone());
        inventory.setItemInOffHand(storage[slot].clone());
        return;
      }
    }
  }

  private void selectBestMeleeWeapon(Player fake) {
    PlayerInventory inventory = fake.getInventory();
    int currentScore = weaponScore(inventory.getItemInMainHand());
    int bestSlot = -1;
    int bestScore = currentScore;
    ItemStack[] storage = inventory.getStorageContents();
    for (int slot = 0; slot < storage.length; slot++) {
      int score = weaponScore(storage[slot]);
      if (score > bestScore) {
        bestScore = score;
        bestSlot = slot;
      }
    }
    if (bestSlot >= 0) {
      ItemStack oldHand = inventory.getItemInMainHand();
      ItemStack selected = inventory.getItem(bestSlot);
      inventory.setItem(bestSlot, oldHand == null || oldHand.getType().isAir() ? null : oldHand.clone());
      inventory.setItemInMainHand(selected.clone());
    }
  }

  private int weaponScore(ItemStack item) {
    if (item == null || item.getType().isAir()) return -1;
    String name = item.getType().name();
    int tier = materialTier(name);
    if (name.endsWith("_SWORD")) return 100 + tier * 10 + (name.startsWith("NETHERITE") ? 4 : 0);
    if (name.endsWith("_AXE")) return 95 + tier * 10 + (name.startsWith("NETHERITE") ? 4 : 0);
    if (name.equals("MACE")) return 165;
    if (name.equals("TRIDENT")) return 155;
    return -1;
  }

  private int materialTier(String name) {
    if (name.startsWith("NETHERITE")) return 6;
    if (name.startsWith("DIAMOND")) return 5;
    if (name.startsWith("IRON")) return 4;
    if (name.startsWith("STONE")) return 3;
    if (name.startsWith("GOLDEN")) return 2;
    if (name.startsWith("WOODEN")) return 1;
    return 0;
  }

  private double weaponDamage(ItemStack item) {
    if (item == null) return 1.0;
    String name = item.getType().name();
    if (name.equals("MACE")) return 8.5;
    if (name.equals("TRIDENT")) return 8.0;
    if (name.startsWith("NETHERITE") && name.endsWith("_AXE")) return 9.0;
    if (name.startsWith("DIAMOND") && name.endsWith("_AXE")) return 8.0;
    if (name.startsWith("IRON") && name.endsWith("_AXE")) return 7.0;
    if (name.startsWith("NETHERITE")) return 8.0;
    if (name.startsWith("DIAMOND")) return 7.0;
    if (name.startsWith("IRON")) return 6.0;
    if (name.startsWith("STONE")) return 5.0;
    return 4.0;
  }

  private int findRangedWeapon(PlayerInventory inventory) {
    ItemStack[] storage = inventory.getStorageContents();
    for (int i = 0; i < storage.length; i++) {
      if (storage[i] != null && (storage[i].getType() == Material.BOW || storage[i].getType() == Material.CROSSBOW)) return i;
    }
    ItemStack main = inventory.getItemInMainHand();
    return main.getType() == Material.BOW || main.getType() == Material.CROSSBOW ? -2 : -1;
  }

  private boolean hasArrow(PlayerInventory inventory) {
    for (ItemStack item : inventory.getStorageContents()) {
      if (item != null && (item.getType() == Material.ARROW || item.getType() == Material.SPECTRAL_ARROW || item.getType() == Material.TIPPED_ARROW)) return true;
    }
    return false;
  }

  private void fireArrow(Player fake, LivingEntity target) {
    PlayerInventory inventory = fake.getInventory();
    int weaponSlot = findRangedWeapon(inventory);
    if (weaponSlot == -1) return;
    if (weaponSlot >= 0) {
      ItemStack oldHand = inventory.getItemInMainHand();
      ItemStack ranged = inventory.getItem(weaponSlot);
      inventory.setItem(weaponSlot, oldHand == null || oldHand.getType().isAir() ? null : oldHand.clone());
      inventory.setItemInMainHand(ranged.clone());
    }
    int arrowSlot = -1;
    ItemStack[] storage = inventory.getStorageContents();
    for (int i = 0; i < storage.length; i++) {
      if (storage[i] != null && (storage[i].getType() == Material.ARROW || storage[i].getType() == Material.SPECTRAL_ARROW || storage[i].getType() == Material.TIPPED_ARROW)) {
        arrowSlot = i;
        break;
      }
    }
    if (arrowSlot < 0) return;
    Vector direction = target.getEyeLocation().toVector().subtract(fake.getEyeLocation().toVector()).normalize();
    float spread = 0.25f + getTier(fake).ordinal() * 0.06f;
    Arrow arrow = fake.getWorld().spawnArrow(fake.getEyeLocation(), direction, 2.8f, spread);
    arrow.setShooter(fake);
    arrow.setDamage(4.0 + (PvpTier.values().length - 1 - getTier(fake).ordinal()) * 0.25);
    ItemStack ammunition = inventory.getItem(arrowSlot);
    if (ammunition.getAmount() <= 1) inventory.setItem(arrowSlot, null);
    else ammunition.setAmount(ammunition.getAmount() - 1);
    fake.swingMainHand();
  }

  private void tryEatFood(Player fake) {
    if (fake.getHealth() > settings.getDouble("equipment.heal-below-health", 10.0)) return;
    PlayerInventory inventory = fake.getInventory();
    int bestSlot = -1;
    int bestValue = 0;
    ItemStack[] storage = inventory.getStorageContents();
    for (int i = 0; i < storage.length; i++) {
      int value = foodValue(storage[i]);
      if (value > bestValue) {
        bestValue = value;
        bestSlot = i;
      }
    }
    if (bestSlot < 0) return;
    ItemStack food = inventory.getItem(bestSlot);
    if (food.getAmount() <= 1) inventory.setItem(bestSlot, null);
    else food.setAmount(food.getAmount() - 1);
    fake.setHealth(Math.min(20.0, fake.getHealth() + bestValue));
  }

  private int foodValue(ItemStack item) {
    if (item == null) return 0;
    return switch (item.getType().name()) {
      case "GOLDEN_APPLE", "ENCHANTED_GOLDEN_APPLE" -> 8;
      case "COOKED_BEEF", "COOKED_PORKCHOP", "COOKED_MUTTON", "COOKED_RABBIT", "COOKED_SALMON", "COOKED_COD" -> 6;
      case "BREAD", "BAKED_POTATO", "COOKED_CHICKEN", "PUMPKIN_PIE", "CARROT" -> 4;
      case "APPLE", "POTATO", "DRIED_KELP", "MELON_SLICE" -> 2;
      default -> 0;
    };
  }

  private boolean sameTeam(Player first, Player second) {
    if (Bukkit.getScoreboardManager() == null) return false;
    var scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
    var firstTeam = scoreboard.getEntryTeam(first.getName());
    var secondTeam = scoreboard.getEntryTeam(second.getName());
    return firstTeam != null && secondTeam != null && firstTeam.getName().equals(secondTeam.getName());
  }

  /** A shield-equipped fake player gets a frontal damage reduction while in an AI combat mode. */
  @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
  public void onCombatDamage(EntityDamageByEntityEvent event) {
    if (!(event.getEntity() instanceof Player fake)) return;
    State state = states.get(fake.getUniqueId());
    if (state == null || fake.getInventory().getItemInOffHand().getType() != Material.SHIELD) return;
    Entity attacker = event.getDamager();
    if (!(attacker instanceof LivingEntity living) || living.getWorld() != fake.getWorld()) return;
    Vector towardAttacker = living.getLocation().toVector().subtract(fake.getLocation().toVector()).normalize();
    Vector facing = fake.getLocation().getDirection().normalize();
    if (facing.dot(towardAttacker) > 0.2) {
      double reduction = settings.getDouble("combat.shield-damage-multiplier", 0.45);
      event.setDamage(event.getDamage() * Math.max(0.0, Math.min(1.0, reduction)));
      fake.swingOffHand();
    }
    if (fake.getHealth() <= 8.0 && fake.getTicksLived() >= state.nextDodgeTick) {
      Vector away = fake.getLocation().toVector().subtract(living.getLocation().toVector());
      away.setY(0);
      if (away.lengthSquared() > 0.001) {
        away.normalize().multiply(0.38).setY(0.12);
        fake.setVelocity(fake.getVelocity().add(away));
        state.nextDodgeTick = fake.getTicksLived() + Math.max(12, getTier(fake).attackInterval());
      }
    }
  }
}
