package io.github.hello09x.fakeplayer.core.manager;

import com.google.common.io.ByteStreams;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.github.hello09x.fakeplayer.core.Main;
import io.github.hello09x.fakeplayer.core.config.FakeplayerConfig;
import io.github.hello09x.fakeplayer.core.util.ProxySupport;
import io.github.hello09x.fakeplayer.core.util.Schedulers;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.jetbrains.annotations.NotNull;

@Singleton
public class WildFakeplayerManager implements PluginMessageListener, Listener {

  private static final Logger log = Main.getInstance().getLogger();

  /**
   * 是否挂在代理端后面 (BungeeCord 传统转发或 Velocity 现代转发)
   *
   * @see ProxySupport#isProxied()
   */
  private static final boolean IS_PROXIED = ProxySupport.isProxied();

  private static final String CHANNEL = "BungeeCord";
  private static final String SUB_CHANNEL = "PlayerList";

  /**
   * 定义探测到连续 n 次不在线时进行清理 <br>
   * 仅在 {@link #IS_PROXIED} 为 {@code true} 时生效
   */
  private static final int CLEANUP_THRESHOLD = 2;

  private static final int CLEANUP_PERIOD = 6000;

  private final FakeplayerManager manager;
  private final FakeplayerConfig config;
  private final Map<String, AtomicInteger> offline = new HashMap<>();

  @Inject
  public WildFakeplayerManager(FakeplayerManager manager, FakeplayerConfig config) {
    this.manager = manager;
    this.config = config;
    Schedulers.globalTimer(Main.getInstance(), 0, CLEANUP_PERIOD, this::cleanup);
  }

  /**
   * 创建者退出后立即清理其假人, 而不必等待定时轮询。
   *
   * <p>按 {@code follow-quiting-force} 开关启用, 延迟 {@code follow-quiting-force-delay} 秒执行;
   * 若创建者在该延迟内重新上线 (快速重连或切换服务器后返回), 则保留其假人。
   */
  @EventHandler
  public void handleFollowQuitingForce(@NotNull PlayerQuitEvent event) {
    if (!config.isFollowQuiting() || !config.isFollowQuitingForce()) {
      return;
    }

    var creator = event.getPlayer();
    var creatorUuid = creator.getUniqueId();
    var delayTicks = Math.max(1, config.getFollowQuitingForceDelay()) * 20L;
    for (var target : this.manager.getAll(creator)) {
      // 在假人所属区域线程上移除 (Folia 兼容)
      Schedulers.entityLater(
          Main.getInstance(),
          target,
          delayTicks,
          () -> {
            // 创建者已经回到服务器, 说明只是快速重连, 不要误删
            if (Bukkit.getPlayer(creatorUuid) != null) {
              return;
            }
            manager.remove(target.getName(), "Creator offline");
          });
    }
  }

  @Override
  public void onPluginMessageReceived(
      @NotNull String channel, @NotNull Player player, byte @NotNull [] message) {
    if (!channel.equals(CHANNEL)) {
      return;
    }

    @SuppressWarnings("UnstableApiUsage")
    var in = ByteStreams.newDataInput(message);
    if (!in.readUTF().equals(SUB_CHANNEL)) {
      return;
    }

    if (!in.readUTF().equals("ALL")) {
      return;
    }

    var players = new HashSet<String>();
    players.addAll(Arrays.asList(in.readUTF().split(", ")));
    players.addAll(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList());
    this.cleanup0(players);
  }

  /**
   * 清除所有不在 {@code online} 列表中的玩家的假人
   *
   * @param online 在线玩家
   */
  public void cleanup0(@NotNull Set<String> online) {
    @SuppressWarnings("all")
    var group = manager.getAll().stream().collect(Collectors.groupingBy(manager::getCreatorName));

    for (var entry : group.entrySet()) {
      var creator = entry.getKey();
      if (creator.equals("CONSOLE")) {
        continue;
      }

      var targets = entry.getValue();
      if (targets.isEmpty() || online.contains(creator)) {
        continue;
      }

      if (offline.computeIfAbsent(creator, x -> new AtomicInteger()).incrementAndGet()
          < CLEANUP_THRESHOLD) {
        continue;
      }

      for (var target : targets) {
        manager.remove(target.getName(), "Creator offline");
      }
      log.info(
          "%s is offline more than %d ticks, removing %d fake players"
              .formatted(creator, CLEANUP_PERIOD * CLEANUP_THRESHOLD, targets.size()));
    }

    for (var player : online) {
      offline.remove(player);
    }
  }

  /** 清理召唤者下线的假人 */
  public void cleanup() {
    if (!config.isFollowQuiting()) {
      return;
    }

    // 未挂代理时立即清理
    if (!IS_PROXIED) {
      this.cleanup0(
          Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toSet()));
      return;
    }

    // BungeeCord 服务器请求获取所有服务器在线玩家后
    // 在接收到在线列表后再进行清理
    var recipient =
        Bukkit.getServer().getOnlinePlayers().stream()
            .filter(manager::isNotFake)
            .findAny()
            .orElse(null);

    if (recipient == null) {
      return;
    }

    @SuppressWarnings("UnstableApiUsage")
    var out = ByteStreams.newDataOutput();
    out.writeUTF(SUB_CHANNEL);
    out.writeUTF("ALL");
    recipient.sendPluginMessage(Main.getInstance(), CHANNEL, out.toByteArray());
  }
}
