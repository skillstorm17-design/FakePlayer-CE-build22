package io.github.hello09x.fakeplayer.core.command;

public interface Permission {

  String spawn = "fakeplayer.command.spawn";
  String spawnName = "fakeplayer.command.spawn.name";
  String spawnNameForceReal = "fakeplayer.command.spawn.name.force-real";
  String spawnLocation = "fakeplayer.command.spawn.location";
  String spawnUUID = "fakeplayer.command.spawn.uuid";

  String rename = "fakeplayer.command.rename";
  String renameForce = "fakeplayer.command.rename.force";

  String select = "fakeplayer.command.select";
  String selection = "fakeplayer.command.selection";
  String goto_ = "fakeplayer.command.goto";
  String follow = "fakeplayer.command.follow";
  String fight = "fakeplayer.command.fight";
  String guard = "fakeplayer.command.guard";
  String pvp = "fakeplayer.command.pvp";
  String pvpinfo = "fakeplayer.command.pvpinfo";

  String kick = "fakeplayer.command.kick";
  String kill = "fakeplayer.command.kill";
  String list = "fakeplayer.command.list";
  String distance = "fakeplayer.command.distance";
  String drop = "fakeplayer.command.drop";
  String dropstack = "fakeplayer.command.dropstack";
  String dropinv = "fakeplayer.command.dropinv";
  String skin = "fakeplayer.command.skin";
  String invsee = "fakeplayer.command.invsee";
  String enderchest = "fakeplayer.command.enderchest";
  String hold = "fakeplayer.command.hold";
  String status = "fakeplayer.command.status";
  String respawn = "fakeplayer.command.respawn";
  String expme = "fakeplayer.command.expme";
  String tp = "fakeplayer.command.tp";
  String tphere = "fakeplayer.command.tphere";
  String tps = "fakeplayer.command.tps";
  String set = "fakeplayer.command.set";
  String setping = "fakeplayer.command.setping";
  String config = "fakeplayer.command.config";
  String mine = "fakeplayer.command.mine";
  String attack = "fakeplayer.command.attack";
  String use = "fakeplayer.command.use";
  String jump = "fakeplayer.command.jump";
  String sneak = "fakeplayer.command.sneak";
  String sprint = "fakeplayer.command.sprint";
  String look = "fakeplayer.command.look";
  String turn = "fakeplayer.command.turn";
  String move = "fakeplayer.command.move";
  String ride = "fakeplayer.command.ride";
  String swap = "fakeplayer.command.swap";
  String replenish = "fakeplayer.config.replenish";
  String replenishFromChest = "fakeplayer.config.replenish.chest";
  String replaceTools = "fakeplayer.config.replace-tools";
  String autofish = "fakeplayer.config.autofish";
  String sleep = "fakeplayer.command.sleep";
  String wakeup = "fakeplayer.command.wakeup";
  String autosleep = "fakeplayer.command.autosleep";
  String cmd = "fakeplayer.command.cmd";
  String say = "fakeplayer.command.say";
  String aichat = "fakeplayer.command.aichat";
  String stop = "fakeplayer.command.stop";
  String password = "fakeplayer.command.password";
  String changepassword = "fakeplayer.command.changepassword";
}
