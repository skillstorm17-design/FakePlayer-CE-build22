package io.github.hello09x.fakeplayer.core.manager;

import com.google.inject.Singleton;
import io.github.hello09x.fakeplayer.core.entity.Fakeplayer;
import java.util.*;
import java.util.stream.Stream;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

@Singleton
public class FakeplayerList {

  // EasyBot 等第三方插件反射读这个字段，并用原始大小写的玩家名 containsKey。
  // 本插件统一按小写键存取，改成大小写不敏感的 Map 后两边都能命中（issue #132）。
  private final Map<String, Fakeplayer> playersByName =
      new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
  private final Map<UUID, Fakeplayer> playersByUUID = new HashMap<>();
  private final Map<String, List<Fakeplayer>> playersByCreator = new HashMap<>();

  private static @NotNull String nameKey(@NotNull String name) {
    return name.toLowerCase(Locale.ROOT);
  }

  /**
   * 添加一个假人到假人清单
   *
   * @param player 假人
   */
  public boolean add(@NotNull Fakeplayer player) {
    var name = nameKey(player.getName());
    if (this.playersByName.containsKey(name) || this.playersByUUID.containsKey(player.getUUID())) {
      return false;
    }
    this.playersByName.put(name, player);
    this.playersByUUID.put(player.getUUID(), player);
    this.playersByCreator
        .computeIfAbsent(player.getCreator().getName(), key -> new LinkedList<>())
        .add(player);
    return true;
  }

  /**
   * 通过假人的名称获取假人
   *
   * @param name 名称
   * @return 假人
   */
  public @Nullable Fakeplayer getByName(@NotNull String name) {
    return this.playersByName.get(nameKey(name));
  }

  /**
   * 通过 UUID 获取假人
   *
   * @param uuid UUID
   * @return 假人
   */
  public @Nullable Fakeplayer getByUUID(@NotNull UUID uuid) {
    return this.playersByUUID.get(uuid);
  }

  /**
   * 获取创建者创建的所有假人
   *
   * @param creator 创建者
   * @return 假人
   */
  public @NotNull @Unmodifiable List<Fakeplayer> getByCreator(@NotNull String creator) {
    return Optional.ofNullable(this.playersByCreator.get(creator))
        .map(Collections::unmodifiableList)
        .orElse(Collections.emptyList());
  }

  /**
   * 移除一个假人
   *
   * @param player 假人
   */
  public boolean remove(@NotNull Fakeplayer player) {
    var name = nameKey(player.getName());
    if (this.playersByName.get(name) != player
        || this.playersByUUID.get(player.getUUID()) != player) {
      return false;
    }
    this.playersByName.remove(name);
    this.playersByUUID.remove(player.getUUID());
    Optional.ofNullable(this.playersByCreator.get(player.getCreator().getName()))
        .ifPresent(players -> players.remove(player));
    return true;
  }

  /**
   * 通过 UUID 移除假人
   *
   * @param uuid UUID
   * @return 被移除的假人
   */
  public @Nullable Fakeplayer removeByUUID(@NotNull UUID uuid) {
    var player = getByUUID(uuid);
    if (player == null) {
      return null;
    }
    this.remove(player);
    return player;
  }

  /**
   * 获取创建的数量
   *
   * @param creator 玩家
   * @return 数量
   */
  public int countByCreator(@NotNull String creator) {
    return Optional.ofNullable(this.playersByCreator.get(creator)).map(List::size).orElse(0);
  }

  /**
   * 获取所有假人
   *
   * @return 假人
   */
  public @NotNull @Unmodifiable List<Fakeplayer> getAll() {
    return List.copyOf(this.playersByUUID.values());
  }

  public @NotNull Stream<Fakeplayer> stream() {
    return this.playersByUUID.values().stream();
  }

  public int getSize() {
    return this.playersByUUID.size();
  }
}
