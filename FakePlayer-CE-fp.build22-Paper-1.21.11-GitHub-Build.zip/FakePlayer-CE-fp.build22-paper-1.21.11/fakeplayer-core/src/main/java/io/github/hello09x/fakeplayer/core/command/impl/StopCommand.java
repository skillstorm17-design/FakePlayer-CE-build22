package io.github.hello09x.fakeplayer.core.command.impl;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import dev.jorel.commandapi.exceptions.WrapperCommandSyntaxException;
import dev.jorel.commandapi.executors.CommandArguments;
import io.github.hello09x.fakeplayer.core.manager.action.ActionManager;
import io.github.hello09x.fakeplayer.core.manager.combat.CombatAIManager;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

/**
 * @author tanyaofei
 * @since 2024/7/28
 */
@Singleton
public class StopCommand extends AbstractCommand {

  private final ActionManager actionManager;
  private final CombatAIManager combatAI;

  @Inject
  public StopCommand(ActionManager actionManager, CombatAIManager combatAI) {
    this.actionManager = actionManager;
    this.combatAI = combatAI;
  }

  public void stop(@NotNull CommandSender sender, @NotNull CommandArguments args)
      throws WrapperCommandSyntaxException {
    var fake = super.getFakeplayer(sender, args);
    combatAI.stop(fake);
    actionManager.stop(fake);
  }
}
