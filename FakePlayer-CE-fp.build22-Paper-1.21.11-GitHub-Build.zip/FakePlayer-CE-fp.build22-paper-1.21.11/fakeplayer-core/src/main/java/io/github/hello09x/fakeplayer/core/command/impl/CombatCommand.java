package io.github.hello09x.fakeplayer.core.command.impl;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import dev.jorel.commandapi.CommandAPI;
import dev.jorel.commandapi.exceptions.WrapperCommandSyntaxException;
import dev.jorel.commandapi.executors.CommandArguments;
import io.github.hello09x.fakeplayer.core.manager.combat.CombatAIManager;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

@Singleton
public final class CombatCommand extends AbstractCommand {

  private final CombatAIManager combatAI;

  @Inject
  public CombatCommand(CombatAIManager combatAI) {
    this.combatAI = combatAI;
  }

  public void follow(@NotNull CommandSender sender, @NotNull CommandArguments args)
      throws WrapperCommandSyntaxException {
    Player fake = getFakeplayer(sender, args);
    Player target = onlineTarget(args);
    if (fake.equals(target)) throw CommandAPI.failWithString("A fake player cannot follow itself.");
    combatAI.follow(fake, target);
    sender.sendMessage("§a" + fake.getName() + " is now following " + target.getName() + ".");
  }

  public void fight(@NotNull CommandSender sender, @NotNull CommandArguments args)
      throws WrapperCommandSyntaxException {
    Player fake = getFakeplayer(sender, args);
    Player target = onlineTarget(args);
    if (fake.equals(target)) throw CommandAPI.failWithString("A fake player cannot fight itself.");
    if (fake.getWorld() != target.getWorld()) {
      throw CommandAPI.failWithString("The fake player and target must be in the same world.");
    }
    if (combatAI.requiresWorldPvp() && !fake.getWorld().getPVP()) {
      throw CommandAPI.failWithString("PvP is disabled in this world. Enable world PvP before using /fp fight.");
    }
    combatAI.fight(fake, target);
    sender.sendMessage("§c" + fake.getName() + " is now targeting " + target.getName() + " (tier " + combatAI.getTier(fake).name() + ").");
  }

  public void guard(@NotNull CommandSender sender, @NotNull CommandArguments args)
      throws WrapperCommandSyntaxException {
    Player fake = getFakeplayer(sender, args);
    combatAI.guard(fake);
    sender.sendMessage("§a" + fake.getName() + " is guarding this position. Use /fp stop to cancel.");
  }

  public void setTier(@NotNull CommandSender sender, @NotNull CommandArguments args)
      throws WrapperCommandSyntaxException {
    Player fake = getFakeplayer(sender, args);
    String tierName = String.valueOf(args.get("tier"));
    CombatAIManager.PvpTier tier;
    try {
      tier = CombatAIManager.PvpTier.parse(tierName);
    } catch (IllegalArgumentException exception) {
      throw CommandAPI.failWithString("Unknown PvP tier. Use HT1-HT5 or LT1-LT5.");
    }
    combatAI.setTier(fake, tier);
    sender.sendMessage("§a" + fake.getName() + " PvP tier set to " + tier.name() + " (" + tier.description() + ").");
  }

  public void info(@NotNull CommandSender sender, @NotNull CommandArguments args)
      throws WrapperCommandSyntaxException {
    Player fake = getFakeplayer(sender, args);
    sender.sendMessage("§6FakePlayer AI: §f" + fake.getName());
    sender.sendMessage("§eMode: §f" + combatAI.getMode(fake));
    sender.sendMessage("§ePvP tier: §f" + combatAI.getTier(fake).name() + " - " + combatAI.getTier(fake).description());
  }

  private Player onlineTarget(CommandArguments args) throws WrapperCommandSyntaxException {
    String name = String.valueOf(args.get("target"));
    Player target = Bukkit.getPlayerExact(name);
    if (target == null || !target.isOnline()) {
      throw CommandAPI.failWithString("Player '" + name + "' is not online. Enter the exact online player name.");
    }
    return target;
  }
}
