package io.github.hello09x.fakeplayer.core.repository.model;

import io.github.hello09x.fakeplayer.api.spi.ActionSetting;
import io.github.hello09x.fakeplayer.api.spi.ActionType;
import io.github.hello09x.fakeplayer.core.command.Permission;
import java.util.List;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Function;
import lombok.AllArgsConstructor;
import lombok.Getter;
import net.kyori.adventure.translation.Translatable;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author tanyaofei
 * @since 2024/8/13
 */
@Getter
@AllArgsConstructor
public enum Feature implements Translatable, Singletons {

  /** 是否具有碰撞箱 */
  collidable(
      "fakeplayer.config.collidable",
      List.of(Permission.config),
      List.of("true", "false"),
      "true",
      faker -> String.valueOf(faker.isCollidable()),
      (faker, value) -> faker.setCollidable(Boolean.parseBoolean(value))),

  /** 是否无敌 */
  invulnerable(
      "fakeplayer.config.invulnerable",
      List.of(Permission.config),
      List.of("true", "false"),
      "true",
      faker -> String.valueOf(faker.isInvulnerable()),
      (faker, value) -> faker.setInvulnerable(Boolean.parseBoolean(value))),

  /** 金刚狼模式 -> 超强的再生能力 */
  wolverine(
      "fakeplayer.config.wolverine",
      List.of(Permission.config),
      List.of("true", "false"),
      "false",
      fake ->
          String.valueOf(
              Optional.ofNullable(fake.getPotionEffect(PotionEffectType.REGENERATION))
                  .map(PotionEffect::isInfinite)
                  .orElse(false)),
      (faker, value) -> {
        if (Boolean.parseBoolean(value)) {
          faker.addPotionEffect(
              new PotionEffect(
                  PotionEffectType.REGENERATION, PotionEffect.INFINITE_DURATION, 4, true, true));
        } else {
          faker.removePotionEffect(PotionEffectType.REGENERATION);
        }
      }),

  /** 是否自动看向实体 */
  look_at_entity(
      "fakeplayer.config.look_at_entity",
      List.of(Permission.config, Permission.look),
      List.of("true", "false"),
      "false",
      faker ->
          String.valueOf(
              actionManager.get().hasActiveAction(faker, ActionType.LOOK_AT_NEAREST_ENTITY)),
      (faker, value) -> {
        if (Boolean.parseBoolean(value)) {
          actionManager
              .get()
              .setAction(faker, ActionType.LOOK_AT_NEAREST_ENTITY, ActionSetting.continuous());
        } else {
          actionManager
              .get()
              .setAction(faker, ActionType.LOOK_AT_NEAREST_ENTITY, ActionSetting.stop());
        }
      }),

  /** 是否能够拾取物品 */
  pickup_items(
      "fakeplayer.config.pickup_items",
      List.of(Permission.config),
      List.of("true", "false"),
      "true",
      faker -> String.valueOf(faker.getCanPickupItems()),
      (faker, value) -> faker.setCanPickupItems(Boolean.parseBoolean(value))),

  /** 是否使用皮肤 */
  skin(
      "fakeplayer.config.skin",
      List.of(Permission.config),
      List.of("true", "false"),
      "true",
      null,
      null),

  /** 是否自动补货 */
  replenish(
      "fakeplayer.config.replenish",
      List.of(Permission.config, Permission.replenish),
      List.of("true", "false"),
      "false",
      faker -> String.valueOf(replenishManager.get().isReplenish(faker)),
      (faker, value) -> replenishManager.get().setReplenish(faker, Boolean.parseBoolean(value))),

  /** 是否自动替换低耐久工具 */
  replace_tools(
      "fakeplayer.config.replace_tools",
      List.of(Permission.config, Permission.replaceTools),
      List.of("true", "false"),
      "false",
      faker -> String.valueOf(replenishManager.get().isReplaceTools(faker)),
      (faker, value) -> replenishManager.get().setReplaceTools(faker, Boolean.parseBoolean(value))),

  /** 是否自动钓鱼 */
  autofish(
      "fakeplayer.config.autofish",
      List.of(Permission.config, Permission.autofish),
      List.of("true", "false"),
      "false",
      faker -> String.valueOf(autofishManager.get().isAutofish(faker)),
      (faker, value) -> autofishManager.get().setAutofish(faker, Boolean.parseBoolean(value))),

  /**
   * 假人的模拟距离 (区块半径); -1 表示沿用世界设置
   *
   * <p>可选值为空表示该项接受任意整数, 而不是 true/false 这类枚举
   */
  simulation_distance(
      "fakeplayer.config.simulation_distance",
      List.of(Permission.config),
      List.of(),
      "-1",
      faker -> String.valueOf(faker.getSimulationDistance()),
      (faker, value) -> {
        var distance = Integer.parseInt(value);
        faker.setSimulationDistance(
            distance >= 0 ? distance : faker.getWorld().getSimulationDistance());
      }),
  ;

  @NotNull final String translationKey;

  @NotNull final List<String> permissions;

  @NotNull final List<String> options;

  @NotNull final String defaultOption;

  @Nullable final Function<Player, String> detector;

  @Nullable final BiConsumer<Player, String> modifier;

  @Override
  public @NotNull String translationKey() {
    return this.translationKey;
  }

  public boolean hasDetector() {
    return this.detector != null;
  }

  /** 是否接受任意整数取值 (options 为空) */
  public boolean isNumeric() {
    return this.options.isEmpty();
  }

  public boolean hasModifier() {
    return this.modifier != null;
  }

  public boolean testPermissions(@NotNull CommandSender sender) {
    if (this.permissions.isEmpty()) {
      return true;
    }

    for (var permission : this.permissions) {
      if (!sender.hasPermission(permission)) {
        return false;
      }
    }

    return true;
  }
}
