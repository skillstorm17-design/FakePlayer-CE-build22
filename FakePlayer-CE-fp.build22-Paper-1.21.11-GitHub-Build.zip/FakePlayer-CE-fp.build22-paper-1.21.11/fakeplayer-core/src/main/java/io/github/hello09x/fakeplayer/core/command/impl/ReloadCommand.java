package io.github.hello09x.fakeplayer.core.command.impl;

import static net.kyori.adventure.text.Component.translatable;
import static net.kyori.adventure.text.format.NamedTextColor.GRAY;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import dev.jorel.commandapi.executors.CommandArguments;
import io.github.hello09x.devtools.core.translation.PluginTranslator;
import io.github.hello09x.fakeplayer.core.aichat.AiChatConfig;
import io.github.hello09x.fakeplayer.core.config.FakeplayerConfig;
import io.github.hello09x.fakeplayer.core.i18n.LangUtils;
import io.github.hello09x.fakeplayer.core.manager.FakeplayerPingSetter;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

@Singleton
public class ReloadCommand extends AbstractCommand {

  private final FakeplayerConfig config;

  private final PluginTranslator translator;

  private final FakeplayerPingSetter pingSetter;

  private final AiChatConfig aiChatConfig;

  @Inject
  public ReloadCommand(
      FakeplayerConfig config,
      PluginTranslator translator,
      FakeplayerPingSetter pingSetter,
      AiChatConfig aiChatConfig) {
    this.config = config;
    this.translator = translator;
    this.pingSetter = pingSetter;
    this.aiChatConfig = aiChatConfig;
  }

  public void reload(@NotNull CommandSender sender, @NotNull CommandArguments args) {
    config.reload();
    aiChatConfig.reload();
    pingSetter.restart();
    LangUtils.send(sender, translatable("fakeplayer.command.generic.success", GRAY));
    if (config.isConfigFileOutOfDate()) {
      LangUtils.send(sender, translatable("fakeplayer.configuration.out-of-date", GRAY));
    }
  }

  public void reloadTranslation(@NotNull CommandSender sender, @NotNull CommandArguments args) {
    translator.reload();
    LangUtils.send(sender, translatable("fakeplayer.command.generic.success"));
  }
}
