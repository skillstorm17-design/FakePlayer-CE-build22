#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
java -version
major="$(java -version 2>&1 | head -n1 | sed -E 's/.*version "([0-9]+).*/\1/')"
if [[ "$major" != "21" ]]; then
  echo "This package targets Java 21 (detected: $major)." >&2
  exit 1
fi
./gradlew :fakeplayer-dist:shadowJar --no-daemon --console=plain
echo "Built: fakeplayer-dist/build/libs/fakeplayer-fp.build22.jar"
