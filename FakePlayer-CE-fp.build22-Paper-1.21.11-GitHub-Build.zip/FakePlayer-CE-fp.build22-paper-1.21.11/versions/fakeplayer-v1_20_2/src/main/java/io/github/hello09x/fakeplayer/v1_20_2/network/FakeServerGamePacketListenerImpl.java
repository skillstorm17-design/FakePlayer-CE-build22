package io.github.hello09x.fakeplayer.v1_20_2.network;

import io.github.hello09x.fakeplayer.api.spi.NMSServerGamePacketListener;
import io.github.hello09x.fakeplayer.core.Main;
import io.github.hello09x.fakeplayer.core.manager.FakeplayerManager;
import io.github.hello09x.fakeplayer.core.util.PacketSendGuard;
import io.netty.buffer.Unpooled;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.network.Connection;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.bukkit.Bukkit;
import org.bukkit.plugin.messaging.StandardMessenger;
import org.jetbrains.annotations.NotNull;

public class FakeServerGamePacketListenerImpl extends ServerGamePacketListenerImpl
    implements NMSServerGamePacketListener {

  private final FakeplayerManager manager = Main.getInjector().getInstance(FakeplayerManager.class);

  public FakeServerGamePacketListenerImpl(
      @NotNull MinecraftServer server,
      @NotNull Connection connection,
      @NotNull ServerPlayer player,
      @NotNull CommonListenerCookie cookie) {
    super(server, connection, player, cookie);
    Bukkit.getMessenger()
        .registerOutgoingPluginChannel(
            Main.getInstance(), StandardMessenger.validateAndCorrectChannel(BUNGEE_CORD_CHANNEL));
  }

  @Override
  public void send(Packet<?> packet) {
    try {
      this.dispatchPacket(packet);
    } catch (VirtualMachineError | ThreadDeath fatal) {
      throw fatal;
    } catch (Throwable e) {
      // 假人发不出包不能抛给调用方: 别的插件在自己的任务里往假人发消息, 异常会让它们的操作回滚
      PacketSendGuard.onFailure(e);
    }
  }

  private void dispatchPacket(Packet<?> packet) {
    if (packet instanceof ClientboundCustomPayloadPacket p) {
      this.handleCustomPayloadPacket(p);
    }
  }

  private void handleCustomPayloadPacket(@NotNull ClientboundCustomPayloadPacket packet) {
    var payload = packet.payload();
    var identifier = payload.id();
    var channel =
        StandardMessenger.validateAndCorrectChannel(
            identifier.getNamespace() + ":" + identifier.getPath());

    if (!channel.equals(BUNGEE_CORD_CORRECTED_CHANNEL)) {
      return;
    }

    var recipient =
        Bukkit.getOnlinePlayers().stream().filter(manager::isNotFake).findAny().orElse(null);
    if (recipient == null) {
      return;
    }

    var data = new FriendlyByteBuf(Unpooled.buffer());
    try {
      payload.write(data);
      var message = new byte[data.readableBytes()];
      data.getBytes(data.readerIndex(), message);
      recipient.sendPluginMessage(Main.getInstance(), BUNGEE_CORD_CHANNEL, message);
    } finally {
      data.release();
    }
  }

  /** 自定义延迟 (ping), 负数表示使用服务端计算出的真实值 */
  private int fakePing = -1;

  @Override
  public int latency() {
    return this.fakePing >= 0 ? this.fakePing : super.latency();
  }

  @Override
  public void setPing(int ping, boolean broadcast) {
    this.fakePing = ping;
    if (broadcast) {
      // 原版每 30 秒才广播一次延迟, 这里主动广播让 Tab 列表立刻刷新
      this.server
          .getPlayerList()
          .broadcastAll(
              new ClientboundPlayerInfoUpdatePacket(
                  EnumSet.of(ClientboundPlayerInfoUpdatePacket.Action.UPDATE_LATENCY),
                  List.of(this.player)));
    }
  }
}
