package io.github.hello09x.fakeplayer.v26_2.network;

import io.github.hello09x.fakeplayer.core.Main;
import io.github.hello09x.fakeplayer.core.manager.FakeplayerManager;
import io.github.hello09x.fakeplayer.core.network.FakeChannel;
import io.netty.channel.ChannelFutureListener;
import java.net.InetAddress;
import java.util.logging.Logger;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.common.ClientboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class FakeConnection extends Connection {

  private static final Logger log = Main.getInstance().getLogger();
  private final FakeplayerManager manager = Main.getInjector().getInstance(FakeplayerManager.class);

  public FakeConnection(@NotNull InetAddress address) {
    super(PacketFlow.SERVERBOUND);
    this.channel = new FakeChannel(null, address);
    this.address = this.channel.remoteAddress();
    Connection.configureSerialization(this.channel.pipeline(), PacketFlow.SERVERBOUND, false, null);
  }

  @Override
  public boolean isConnected() {
    return true;
  }

  @Override
  public void send(Packet<?> packet, @Nullable ChannelFutureListener channelfuturelistener) {
    this.send(packet, channelfuturelistener, true);
  }

  @Override
  public void send(
      Packet<?> packet, @Nullable ChannelFutureListener channelfuturelistener, boolean flush) {
    // 假人没有真实客户端, 需要主动回应 keepalive, 否则服务端会判定超时把假人踢出
    // (Folia 会 tick 假人的连接, 因此该路径必须处理)
    if (packet instanceof ClientboundKeepAlivePacket keepAlive) {
      if (this.getPacketListener() instanceof ServerGamePacketListenerImpl gameListener) {
        try {
          gameListener.handleKeepAlive(new ServerboundKeepAlivePacket(keepAlive.getId()));
        } catch (Throwable ignored) {
          // ignore
        }
      }
    }
  }

  @Override
  public void send(Packet<?> packet) {
    this.send(packet, null, true);
  }
}
