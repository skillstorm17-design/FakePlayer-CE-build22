pluginManagement {
    repositories {
        gradlePluginPortal()
        maven("https://repo.papermc.io/repository/maven-public/")
    }
}

rootProject.name = "fakeplayer-parent"

include("fakeplayer-api")
include("fakeplayer-core")
include("fakeplayer-dist")
include(":fakeplayer-v1_21_11")
project(":fakeplayer-v1_21_11").projectDir = file("versions/fakeplayer-v1_21_11")
